gp = null;   // GamePanel �I�u�W�F�N�g

			//
			// GamePanel �̊J�n
			//
function gp_start()
{
					// GamePanel �I�u�W�F�N�g
	gp = new GamePanel();
					// �^�C�}�[�̃X�^�[�g
	gp.timerID = setInterval('gp.draw()', 33);
					// �C�x���g���X�i�̒ǉ�
	mp.canvas.addEventListener("mousedown", gp.onMouseDown);
	mp.canvas.addEventListener("keydown", gp.onKeyDown, false);
					// �{�^���̕\������
	document.getElementById('method').style.display = "none";
	document.getElementById('map').style.display = "none";
	document.getElementById('start').style.display = "none";
	document.getElementById('first').style.display = "none";
	document.getElementById('finish').style.display = "none";
	document.getElementById('i_set').style.display = "none";
}
			//
			// GamePanel �I�u�W�F�N�g�i�v���p�e�B�j
			//
function GamePanel()
{
	this.timerID = -1;   // �^�C�}�[
	this.count = 0;   // �J�E���^
	this.mark = new Image();   // �}�[�J�[
	this.mark.src = "image/mark.jpg";
	this.mouse = false;
	this.mark_x = 0;   // �}�[�J�[�̂����W
	this.mark_y = 0;   // �}�[�J�[�̂����W
					// �}�b�v�̑I��
	var k = 0;
	for (var i1 = 0; i1 < document.getElementById('map_sel').options.length; i1++) {
		if (document.getElementById('map_sel').options[i1].selected) {
			k = i1;
			break;
		}
	}
	MP.map = MP.map1[k];
					// ����
							// �����̐�
	this.n_friend = new Array();   // �����̐�
	this.n_friend[0] = parseInt(document.getElementById('fr1').value);
	this.n_friend[1] = parseInt(document.getElementById('fr2').value);
							// �����̏������
	this.f_state = new Array();   // 0:���݁C1:���쒆�C-1�F����
	this.friend = new Array();
	for (var i1 = 0; i1 < this.n_friend.length; i1++) {
		this.f_state[i1] = new Array();   // 0:���݁C1:���쒆�C-1�F����
		this.friend[i1] = new Array();
		for (var i2 = 0; i2 < this.n_friend[i1]; i2++) {
			this.f_state[i1][i2] = 0;
			this.friend[i1][i2] = new Friend(i1);
		}
	}
					// �G
							// �G�̐�
	this.n_enemy = new Array();   // �G�̐�
	this.n_enemy[0] = parseInt(document.getElementById('en1').value);
	this.n_enemy[1] = parseInt(document.getElementById('en2').value);
	this.n_e_now = this.n_enemy[0] + this.n_enemy[1];   // �o�����Ă��Ȃ��G�̐�
	this.n_e_now_ex = this.n_e_now;   // ���݂��Ă���G�̐�
							// �G�̏������
	this.e_state = new Array();   // 0:���݁C1:���쒆�C-1�F����
	this.enemy = new Array();
	var k = 0;
	for (var i1 = 0; i1 < this.n_enemy.length; i1++) {
		for (var i2 = 0; i2 < this.n_enemy[i1]; i2++) {
			this.e_state[k] = 0;
			this.enemy[k] = new Enemy(i1);
			k++;
		}
	}
							// ���̓G
	this.next_time = Math.floor(30 * Math.random());
	this.next = Math.floor(this.e_state.length * Math.random());
	if (this.next >= this.e_state.length)
		this.next = this.e_state.length - 1;

	return this;
}
			//
			// GamePanel �I�u�W�F�N�g�i���\�b�h draw�j
			//
GamePanel.prototype.draw = function()
{
	gp.count++;
					// �L�����o�X�̃N���A
	mp.ctx.clearRect(0, 0, mp.canvas.width, mp.canvas.height);
					// �w�i�̕`��
	for (var i1 = 0; i1 < MP.map_col; i1++) {
		var x = MP.block_width * i1;
		for (var i2 = 0; i2 < MP.map_row; i2++) {
			if (MP.map[i2][i1] > 0) {
				var y = i2 * MP.block_height;
				mp.ctx.drawImage(MP.block_image[MP.map[i2][i1]-1], x, y, MP.block_width, MP.block_height);
			}
		}
	}
					// �}�[�J�[�̕`��
	mp.ctx.drawImage(gp.mark, gp.mark_x, gp.mark_y, MP.block_width, MP.block_height);
					// �����̕`��
							// �����P
	for (var i1 = 0; i1 < gp.f_state[0].length; i1++) {
		if (gp.f_state[0][i1] > 0) {
									// ���ֈړ�
			if (gp.friend[0][i1].state == 0) {
				gp.friend[0][i1].x -= gp.friend[0][i1].v;
				if (gp.friend[0][i1].x < 0)
					gp.f_state[0][i1] = -1;
				else {
					var k1 = Math.floor(gp.friend[0][i1].y / MP.block_height);
					var k2 = Math.floor(gp.friend[0][i1].x / MP.block_width);
					if (MP.map[k1][k2] > 0) {
						gp.friend[0][i1].x = (k2 + 1) * MP.block_width;
						var r = Math.random();
						if (k1 == MP.map_row-1 && MP.map[k1-1][k2+1] == 0 || k1 > 0 && k1 < MP.map_row-1 && (MP.map[k1+1][k2+1] > 0 || r > 0.5 && MP.map[k1+1][k2+1] == 0 && MP.map[k1-1][k2+1] == 0))
							gp.friend[0][i1].state = -1;   // ���
						else if (k1 == 0 && MP.map[k1+1][k2+1] == 0 || k1 > 0 && k1 < MP.map_row-1 && (MP.map[k1-1][k2+1] > 0 || r <= 0.5 && MP.map[k1+1][k2+1] == 0 && MP.map[k1-1][k2+1] == 0))
							gp.friend[0][i1].state = 1;   // ����
					}
				}
			}
									// ��ֈړ�
			else if (gp.friend[0][i1].state < 0) {
				gp.friend[0][i1].y -= gp.friend[0][i1].v;
				var k1 = Math.floor((gp.friend[0][i1].y + MP.block_height) / MP.block_height);
				var k2 = Math.floor(gp.friend[0][i1].x / MP.block_width) - 1;
				if (MP.map[k1][k2] == 0) {
					gp.friend[0][i1].y = k1 * MP.block_height;
					gp.friend[0][i1].state = 0;   // ����
				}
				else if (k1 == 0 || MP.map[k1-1][k2+1] > 0)
					gp.friend[0][i1].state = 1;   // ����
			}
									// ���ֈړ�
			else {
				gp.friend[0][i1].y += gp.friend[0][i1].v;
				var k1 = Math.floor(gp.friend[0][i1].y / MP.block_height);
				var k2 = Math.floor(gp.friend[0][i1].x / MP.block_width) - 1;
				if (k1 >= MP.map_row-1) {
					gp.friend[0][i1].y = k1 * MP.block_height;
					if (MP.map[k1][k2] == 0)
						gp.friend[0][i1].state = 0;   // ����
					else
						gp.friend[0][i1].state = -1;   // ���
				}
				else {
					if (MP.map[k1][k2] == 0) {
						gp.friend[0][i1].y = k1 * MP.block_height;
						gp.friend[0][i1].state = 0;   // �E��
					}
					else if (MP.map[k1+1][k2+1] > 0)
						gp.friend[0][i1].state = -1;   // ���
				}
			}
									// �Փ˔���ƕ`��
			if (gp.f_state[0][i1] > 0) {
				var k1 = Math.floor(gp.friend[0][i1].y / MP.block_height);
				var k2 = Math.floor(gp.friend[0][i1].x / MP.block_width);
				for (var i2 = 0; i2 < gp.e_state.length; i2++) {
					if (gp.e_state[i2] > 0) {
						var t1 = Math.floor(gp.enemy[i2].y / MP.block_height);
						var t2 = Math.floor(gp.enemy[i2].x / MP.block_width);
						if (k1 == t1 && k2 == t2) {
							gp.e_state[i2] = -1;
							gp.n_e_now_ex--;
							if (gp.n_e_now_ex == 0) {
								clearInterval(gp.timerID);   // �^�C�}�[�̒�~
								gcp_start();   // �Q�[���N���A
							}
						}
					}
				}
				mp.ctx.drawImage(gp.friend[0][i1].image, gp.friend[0][i1].x, gp.friend[0][i1].y, MP.block_width, MP.block_height);
			}
		}
	}
							// �����Q
	for (var i1 = 0; i1 < gp.f_state[1].length; i1++) {
		if (gp.f_state[1][i1] > 0) {
			var k1 = Math.floor(gp.friend[1][i1].y / MP.block_height);
			var k2 = Math.floor(gp.friend[1][i1].x / MP.block_width);
			for (var i2 = 0; i2 < gp.e_state.length; i2++) {
				if (gp.e_state[i2] > 0) {
					var t1 = Math.floor(gp.enemy[i2].y / MP.block_height);
					var t2 = Math.floor(gp.enemy[i2].x / MP.block_width);
					if (Math.abs(k1-t1) + Math.abs(k2-t2) <= 2) {
						gp.e_state[i2] = -1;
						gp.n_e_now_ex--;
						if (gp.n_e_now_ex == 0) {
							clearInterval(gp.timerID);   // �^�C�}�[�̒�~
							gcp_start();   // �Q�[���N���A
						}
					}
				}
			}
			mp.ctx.drawImage(gp.friend[1][i1].image, gp.friend[1][i1].x, gp.friend[1][i1].y, MP.block_width, MP.block_height);
		}
	}
					// �G�̕`��
	for (var i1 = 0; i1 < gp.e_state.length; i1++) {
		if (gp.e_state[i1] > 0) {
			var sw = 0;
							// �G�P
			if (gp.enemy[i1].type == 0) {
									// �E�ֈړ�
				if (gp.enemy[i1].state == 0) {
					gp.enemy[i1].x += gp.enemy[i1].v;
					var k2 = Math.floor((gp.enemy[i1].x + MP.block_width) / MP.block_width);
					if (k2 >= MP.map_col)
						sw = 1;
					else {
						var k1 = Math.floor(gp.enemy[i1].y / MP.block_height);
						if (MP.map[k1][k2] > 0) {
							gp.enemy[i1].x = (k2 - 1) * MP.block_width;
							var r = Math.random();
							if (k1 == MP.map_row-1 && MP.map[k1-1][k2-1] == 0 || k1 > 0 && k1 < MP.map_row-1 && (MP.map[k1+1][k2-1] > 0 || r > 0.5 && MP.map[k1+1][k2-1] == 0 && MP.map[k1-1][k2-1] == 0))
								gp.enemy[i1].state = -1;   // ���
							else if (k1 == 0 && MP.map[k1+1][k2-1] == 0 || k1 > 0 && k1 < MP.map_row-1 && (MP.map[k1-1][k2-1] > 0 || r <= 0.5 && MP.map[k1+1][k2-1] == 0 && MP.map[k1-1][k2-1] == 0))
								gp.enemy[i1].state = 1;   // ����
						}
					}
				}
									// ��ֈړ�
				else if (gp.enemy[i1].state < 0) {
					gp.enemy[i1].y -= gp.enemy[i1].v;
					var k1 = Math.floor((gp.enemy[i1].y + MP.block_height) / MP.block_height);
					var k2 = Math.floor(gp.enemy[i1].x / MP.block_width) + 1;
					if (MP.map[k1][k2] == 0) {
						gp.enemy[i1].y = k1 * MP.block_height;
						gp.enemy[i1].state = 0;   // �E��
					}
					else if (k1 == 0 || MP.map[k1-1][k2-1] > 0)
						gp.enemy[i1].state = 1;   // ����
				}
									// ���ֈړ�
				else {
					gp.enemy[i1].y += gp.enemy[i1].v;
					var k1 = Math.floor(gp.enemy[i1].y / MP.block_height);
					var k2 = Math.floor(gp.enemy[i1].x / MP.block_width) + 1;
					if (k1 >= MP.map_row-1) {
						gp.enemy[i1].y = k1 * MP.block_height;
						if (MP.map[k1][k2] == 0)
							gp.enemy[i1].state = 0;   // �E��
						else
							gp.enemy[i1].state = -1;   // ���
					}
					else {
						if (MP.map[k1][k2] == 0) {
							gp.enemy[i1].y = k1 * MP.block_height;
							gp.enemy[i1].state = 0;   // �E��
						}
						else if (MP.map[k1+1][k2-1] > 0)
							gp.enemy[i1].state = -1;   // ���
					}
				}
			}
							// �G�Q
			else if (gp.enemy[i1].type == 1) {
				gp.enemy[i1].x += gp.enemy[i1].v;
				var k2 = Math.floor((gp.enemy[i1].x + MP.block_width) / MP.block_width);
				if (k2 >= MP.map_col)
					sw = 1;
			}
							// �Q�[���I�[�o�[���ۂ�
			if (sw == 0)
				mp.ctx.drawImage(gp.enemy[i1].image, gp.enemy[i1].x, gp.enemy[i1].y, MP.block_width, MP.block_height);
			else {
				clearInterval(gp.timerID);   // �^�C�}�[�̒�~
				gop_start();   // �Q�[���I�[�o�[
			}
		}
	}
					// ���̓G
	if (gp.count == gp.next_time) {
		gp.n_e_now--;
		gp.count = 0;
		gp.e_state[gp.next] = 1;
		if (gp.n_e_now > 0) {
			gp.next_time = Math.floor(5 * 30 - 30 * Math.random());
			gp.next = -1;
			while (gp.next < 0) {
				gp.next = Math.floor(gp.e_state.length * Math.random());
				if (gp.next >= gp.e_state.length)
					gp.next = gp.e_state.length - 1;
				if (gp.e_state[gp.next] != 0)
					gp.next = -1;
			}
		}
		else
			gp.next_time = -1;
	}
}
			//
			// Friend �I�u�W�F�N�g�i�v���p�e�B�j
			//
function Friend(sw)
{
	this.image = new Image();
	if (sw == 0)
		this.image.src = "image/friend1.jpg";
	else
		this.image.src = "image/friend2.jpg";

	this.state = 0;   // 0:���ֈړ��C1:���ֈړ��C-1:��ֈړ�

	this.x = 0;
	this.y = 0;
	this.v = 2;   // �ړ����x

	return this;
}
			//
			// Enemy �I�u�W�F�N�g�i�v���p�e�B�j
			//
function Enemy(sw)
{
	this.image = new Image();
	if (sw == 0)
		this.image.src = "image/enemy1.jpg";
	else
		this.image.src = "image/enemy2.jpg";

	this.type = sw;   // �G�̃^�C�v
	this.state = 0;   // 0:�E�ֈړ��C1:���ֈړ��C-1:��ֈړ�

	this.x = 0;
	this.y = Math.floor(MP.map_row * Math.random ());
	if (this.y >= MP.map_row)
		this.y = MP.map_row - 1;
	this.y *= MP.block_height;
	this.v = 2;   // �ړ����x

	return this;
}
			//
			// GamePanel �I�u�W�F�N�g�i���\�b�h onMouseDown�j
			//
GamePanel.prototype.onMouseDown = function(event)
{
	var x_base  = mp.canvas.offsetLeft;   // �L�����o�X�̍���̂����W
	var y_base  = mp.canvas.offsetTop;   // �L�����o�X�̍���̂����W
	var k1 = Math.floor((event.pageY - y_base) / MP.block_height);
	var k2 = Math.floor((event.pageX - x_base) / MP.block_width);
	if (k1 >= 0 && k1 < MP.map_row && k2 >= 0 && k2 < MP.map_col && MP.map[k1][k2] == 0) {
		gp.mark_x = k2 * MP.block_width;
		gp.mark_y = k1 * MP.block_height;
		gp.mouse = true;
	}
}
			//
			// GamePanel �I�u�W�F�N�g�i���\�b�h onKeyDown�j
			//
GamePanel.prototype.onKeyDown = function(event)
{
	if(gp.mouse && event.keyCode >= 49 && event.keyCode <= 51) {
		if (event.keyCode == 49) {   // �L�[ 1
			if (gp.n_friend[0] > 0) {
				gp.n_friend[0]--;
				gp.f_state[0][gp.n_friend[0]] = 1;
				gp.friend[0][gp.n_friend[0]].x = gp.mark_x;
				gp.friend[0][gp.n_friend[0]].y = gp.mark_y;
			}
		}
		else if (event.keyCode == 50) {   // �L�[ 2
			if (gp.n_friend[1] > 0) {
				gp.n_friend[1]--;
				gp.f_state[1][gp.n_friend[1]] = 1;
				gp.friend[1][gp.n_friend[1]].x = gp.mark_x;
				gp.friend[1][gp.n_friend[1]].y = gp.mark_y;
			}
		}
		gp.mark_x = 0;
		gp.mark_y = 0;
		gp.mouse = false;
	}
}
