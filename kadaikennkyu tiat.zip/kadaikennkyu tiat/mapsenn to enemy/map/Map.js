MP = null;  //Map�I�u�W�F�N�g

fanction Map()
{
//�u���b�N�摜
�@this.block_image = new Array();
  this.block_image[0] = new image();
  this.blockimage[0].src = "image/mizu.jpg";
  this.block_image[1] = new Image();
  this.block_image[1].src = "image/kusa.jpg";
// �u���b�N�̑傫��
 this.block_width = 10;   // �u���b�N�̕�
 this.block_height = 10;   // �u���b�N�̍���
//�}�b�v
 this.map_row = 10; //�}�b�v�̍s��
 this.map_row = 15; //�}�b�v�̗�
 this.map1 = new Array();
 for (var i1 = 0; i1 < 4; i1++)
 this.map1[i1] = new Array();
 //�}�b�v1
 this.map1[0][0] = new Array(0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
 this.map1[0][1] = new Array(0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0);
 this.map1[0][2] = new Array(0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 2);
 this.map1[0][3] = new Array(0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 2);
 this.map1[0][4] = new Array(0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0);
 this.map1[0][5] = new Array(0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1);
 this.map1[0][6] = new Array(0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1);
 this.map1[0][7] = new Array(0, 1, 0, 0, 1, 0, 1, 1, 0, 2, 1, 1, 1, 0, 0);
 this.map1[0][8] = new Array(0, 1, 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 2);
 this.map1[0][9] = new Array(0, 1, 0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 2, 0, 2);
 this.map1[0][10] =new Array(0, 1, 0, 0, 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0);
 thia.map = this.map1[0]; //�g�p�}�b�v

return this;
}

map_ed = null; //MapEdit �I�u�W�F�N�g

//MapEdit�@�I�u�W�F�N�g
map_ed = new MapEdit();
// �C�x���g���X�i�̒ǉ�
	mp.canvas.addEventListener("mousedown", map_ed.onMouseDown);
	mp.canvas.addEventListener("keydown", map_ed.onKeyDown, false);
					// �{�^���̕\������
	document.getElementById('method').style.display = "none";
	document.getElementById('map').style.display = "none";
	document.getElementById('start').style.display = "none";
	document.getElementById('first').innerHTML = "�n�j";
	document.getElementById('first').style.display = "";
	document.getElementById('finish').style.display = "none";
	document.getElementById('i_set').style.display = "none";
					// �}�b�v�̑I��
	var k = 0;
	for (var i1 = 0; i1 < document.getElementById('map_sel').options.length; i1++) {
		if (document.getElementById('map_sel').options[i1].selected) {
			k = i1;
			break;
		}
	}
	MP.map = MP.map1[k];
	map_ed.draw();
}
			//
			// MapEdit �I�u�W�F�N�g�i�v���p�e�B�j
			//
function MapEdit()
{
	this.k1 = 0;
	this.k2 = 0;
	this.mouse = false;
	return this;
}
			//
			// MapEdit �I�u�W�F�N�g�i���\�b�h draw�j
			//
MapEdit.prototype.draw = function()
{
					// �L�����o�X�̃N���A
	mp.ctx.clearRect(0, 0, mp.canvas.width, mp.canvas.height);
					// �w�i�̕`��
	for (var i1 = 0; i1 < MP.map_col; i1++) {
		var x = MP.block_width * i1;
		for (var i2 = 0; i2 < MP.map_row; i2++) {
			if (MP.map[i2][i1] > 0) {
				var y = i2 * MP.block_height;
				mp.ctx.drawImage(MP.block_image[MP.map[i2][i1]-1], x, y);
			}
		}
		mp.ctx.moveTo(x, 0);
		mp.ctx.lineTo(x, MP.map_row*MP.block_height);
		mp.ctx.stroke();
		if (i1 == MP.map_col-1) {
			x += MP.block_height;
			mp.ctx.moveTo(x, 0);
			mp.ctx.lineTo(x, MP.map_row*MP.block_height);
			mp.ctx.stroke();
		}
	}

	for (var i1 = 0; i1 < MP.map_row; i1++) {
		var y = i1 * MP.block_height;
		mp.ctx.moveTo(0, y);
		mp.ctx.lineTo(MP.map_col*MP.block_width, y);
		mp.ctx.stroke();
		if (i1 == MP.map_row-1) {
			y += MP.block_width;
			mp.ctx.moveTo(0, y);
			mp.ctx.lineTo(MP.map_col*MP.block_width, y);
			mp.ctx.stroke();
		}
	}
}
			//
			// MapEdit �I�u�W�F�N�g�i���\�b�h onMouseDown�j
			//
MapEdit.prototype.onMouseDown = function(event)
{
	var x_base = mp.canvas.offsetLeft;   // �L�����o�X�̍���̂����W;
	var y_base = mp.canvas.offsetTop;   // �L�����o�X�̍���̂����W;
	var x = event.pageX - x_base;
	var y = event.pageY - y_base;
	map_ed.k1 = Math.floor(y / MP.block_height);
	map_ed.k2 = Math.floor(x / MP.block_width);
	if (map_ed.k1 >= 0 && map_ed.k1 < MP.map_col && map_ed.k2 >= 0 && map_ed.k2 < MP.map_row)
		map_ed.mouse = true;
	else
		map_ed.mouse = false;
}
			//
			// MapEdit �I�u�W�F�N�g�i���\�b�h onKeyDown�j
			//
MapEdit.prototype.onKeyDown = function(event)
{
	if(map_ed.mouse && event.keyCode >= 48 && event.keyCode <= 50) {
		if (event.keyCode == 48)   // �L�[ 0
			MP.map[map_ed.k1][map_ed.k2] = 0;
		else if (event.keyCode == 49)   // �L�[ 1
			MP.map[map_ed.k1][map_ed.k2] = 1;
		else if (event.keyCode == 50)   // �L�[ 2
			MP.map[map_ed.k1][map_ed.k2] = 2;
		map_ed.draw();
	}
}