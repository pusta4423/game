﻿ gp = null;   // GamePanel オブジェクト

			//
			// GamePanel の開始
			//
function gp_start()
{
					// GamePanel オブジェクト
	gp = new GamePanel();
					// タイマーのスタート
	gp.timerID = setInterval('gp.draw()', 33);
					// イベントリスナの追加
	mp.canvas.addEventListener("mousedown", gp.onMouseDown);
	mp.canvas.addEventListener("keydown", gp.onKeyDown, false);
					// ボタンの表示制御
//	document.getElementById('method').style.display = "none";
//	document.getElementById('map').style.display = "none";
	document.getElementById('start').style.display = "none";
	document.getElementById('first').style.display = "none";
	document.getElementById('finish').style.display = "none";
	document.getElementById('i_set').style.display = "none";
}
			//
			// GamePanel オブジェクト（プロパティ）
			//
function GamePanel()
{
	this.timerID = -1;   // タイマー
	this.count = 0;   // カウンタ
	this.mark = new Image();   // マーカー
	this.mark.src = "image/mark.png";
		this.mark_y = 0;   // マーカーのｙ座標
					// マップの選択
	var k = 0;
	for (var i1 = 0; i1 < document.getElementById('map_sel').options.length; i1++) {
		if (document.getElementById('map_sel').options[i1].selected) {
			k = i1;
			break;
		}
	}
	MP.map = MP.map1[k];
					// 味方
							// 味方の数
	this.n_friend = new Array();   // 味方の数
	this.n_friend[0] = parseInt(document.getElementById('fr1').value);
	this.n_friend[1] = parseInt(document.getElementById('fr2').value);
							// 味方の初期状態
	this.f_state = new Array();   // 0:存在，1:動作中，-1：消滅
	this.friend = new Array();
	for (var i1 = 0; i1 < this.n_friend.length; i1++) {
		this.f_state[i1] = new Array();   // 0:存在，1:動作中，-1：消滅
		this.friend[i1] = new Array();
		for (var i2 = 0; i2 < this.n_friend[i1]; i2++) {
			this.f_state[i1][i2] = 0;
			this.friend[i1][i2] = new Friend(i1);
		}
	}
                                         //弾
                                        //弾の初期状態
        this.n_beam = Array();
        this.n_beam[0] = true;
        this.b_state = new Array();   // 0:存在，1:動作中，-1：消滅
        this.beam = new Array();
        for (var i1 = 0; i1 < this.n_beam.length; i1++) {
		for (var i2 = 0; i2 < this.n_beam[i1]; i2++) {
			this.b_state[k] = 0;
			this.beam[k] = new Beam(i1);
			k++;
		}
	}
					// 敵
							// 敵の数
	this.n_enemy = new Array();   // 敵の数 
	this.n_enemy[0] = parseInt(document.getElementById('en1').value);
	this.n_enemy[1] = parseInt(document.getElementById('en2').value);
	this.n_e_now = this.n_enemy[0] + this.n_enemy[1];   // 出現していない敵の数
        this.n_e_now_ex = this.n_e_now;   // 存在している敵の数
							// 敵の初期状態
	this.e_state = new Array();   // 0:存在，1:動作中，-1：消滅
        this.e_hp = new Array();
	this.enemy = new Array();
	for (var i1 = 0; i1 < this.n_enemy.length; i1++) {
		for (var i2 = 0; i2 < this.n_enemy[i1]; i2++) {
			this.e_state[k] = 0;
			this.enemy[k] = new Enemy(i1);
			k++;
		}
	}
							// 次の敵
	this.next_time = Math.floor(30 * Math.random());
	this.next = Math.floor(this.e_state.length * Math.random());
	if (this.next >= this.e_state.length)
		this.next = this.e_state.length - 1;

	return this;
}
			//
			// GamePanel オブジェクト（メソッド draw）
			//
GamePanel.prototype.draw = function()
{
	gp.count++;
		// キャンバスのクリア
	mp.ctx.clearRect(0, 0, mp.canvas.width, mp.canvas.height);
					// 背景の描画
	for (var i1 = 0; i1 < MP.map_col; i1++) {
		var x = MP.block_width * i1;
		for (var i2 = 0; i2 < MP.map_row; i2++) {
			if (MP.map[i2][i1] > 0) {
				var y = i2 * MP.block_height;
				mp.ctx.drawImage(MP.block_image[MP.map[i2][i1]-1], x, y, MP.block_width, MP.block_height);
			}
		}
	}
			// マーカーの描画
	mp.ctx.drawImage(gp.mark, gp.mark_x, gp.mark_y, MP.block_width, MP.block_height); 
                        //味方
	for (var i1 = 0; i1 < gp.f_state[0].length; i1++) {						// 味方 1
                if (gp.f_state[0][i1] > 0) {
			var k1 = Math.floor(gp.friend[0][i1].y / MP.block_height);
			var k2 = Math.floor(gp.friend[0][i1].x / MP.block_width);
			for (var i2 = 0; i2 < gp.e_state.length; i2++) {
				if (gp.e_state[i2] > 0) {
					var t1 = Math.floor(gp.enemy[i2].y / MP.block_height);
					var t2 = Math.floor(gp.enemy[i2].x / MP.block_width);
					if (Math.abs(k1-t1) + Math.abs(k2-t2) <= 2) {
						gp.e_state[i2] = -1;
						gp.n_e_now_ex--;
						if (gp.n_e_now_ex == 0) {
							clearInterval(gp.timerID);   // タイマーの停止
							gcp_start();   // ゲームクリア
						}
					}
				}
			}
			mp.ctx.drawImage(gp.friend[0][i1].image, gp.friend[0][i1].x, gp.friend[0][i1].y, MP.block_width, MP.block_height);
		}
	}
//                                                          for (var i3 = 0; i3 < gp.b_state.length; i3++) {
//                                                                if (gp.b_state[i1] > 0) {
//                                                                         var sw = 0;
//                                                                         
//                                                                         mp.ctx.drawImage(gp.beam[i1].image, gp.beam[i1].x, gp.beam[i1].y, MP.block_width, MP.block_height);
//                                                                 }                        
//                                                          }
//                                                                       var countup = function(){                                                                                 }
//                                                                       setTimeout(countup, 500);
//                                                                       }
//                                                               countup();
//							// 味方2
//        for (var i1 = 0; i1 < gp.f_state[1].length; i1++) {
//		if (gp.f_state[1][i1] > 0)
//			mp.ctx.drawImage(gp.friend[1][i1].image, gp.friend[1][i1].x, gp.friend[1][i1].y, MP.block_width, MP.block_height);
//	}
                                   // 敵の描画
	for (var i1 = 0; i1 < gp.e_state.length; i1++) {
		if (gp.e_state[i1] > 0) {
			var sw = 0;
//			console.log(gp.enemy[i1]);   //敵のステータス				
                                                                // 敵１
			if (gp.enemy[i1].type == 0) {
									// 右へ移動
				if (gp.enemy[i1].state == 0) {
					gp.enemy[i1].x += gp.enemy[i1].v;
					var k2 = Math.floor((gp.enemy[i1].x + MP.block_width) / MP.block_width);
					if (k2 >= MP.map_col)
						sw = 1;
					else {
						var k1 = Math.floor(gp.enemy[i1].y / MP.block_height);
						if (MP.map[k1][k2] > 1) {
							gp.enemy[i1].x = (k2 - 1) * MP.block_width;
							var r = Math.random();
							if (k1 == MP.map_row-1 && MP.map[k1-1][k2-1] == 1 
                                                           || k1 > 0 && k1 < MP.map_row-1 && (MP.map[k1+1][k2-1] > 1 
                                                           || r > 0.5 && MP.map[k1+1][k2-1] == 1 && MP.map[k1-1][k2-1] == 1))
								gp.enemy[i1].state = -1;   // 上へ
							else if (k1 == 0 && MP.map[k1+1][k2-1] == 1 
                                                           || k1 > 0 && k1 < MP.map_row-1 && (MP.map[k1-1][k2-1] > 1 
                                                           || r <= 0.5 && MP.map[k1+1][k2-1] == 1 && MP.map[k1-1][k2-1] == 1))
								gp.enemy[i1].state = 1;   // 下へ
						}
					}
				}
									// 上へ移動
				else if (gp.enemy[i1].state < 0) {
					gp.enemy[i1].y -= gp.enemy[i1].v;
					var k1 = Math.floor((gp.enemy[i1].y + MP.block_height) / MP.block_height);
					var k2 = Math.floor(gp.enemy[i1].x / MP.block_width) + 1;
					if (MP.map[k1][k2] == 1) {
						gp.enemy[i1].y = k1 * MP.block_height;
						gp.enemy[i1].state = 0;   // 右へ
					}
					else if (k1 == 0 || MP.map[k1-1][k2-1] > 1)
						gp.enemy[i1].state = 1;   // 下へ
				}
									// 下へ移動
				else {
					gp.enemy[i1].y += gp.enemy[i1].v;
					var k1 = Math.floor(gp.enemy[i1].y / MP.block_height);
					var k2 = Math.floor(gp.enemy[i1].x / MP.block_width) + 1;
					if (k1 >= MP.map_row-1) {
						gp.enemy[i1].y = k1 * MP.block_height;
						if (MP.map[k1][k2] == 1)
							gp.enemy[i1].state = 0;   // 右へ
						else
							gp.enemy[i1].state = -1;   // 上へ
					}
					else {
						if (MP.map[k1][k2] == 1) {
							gp.enemy[i1].y = k1 * MP.block_height;
							gp.enemy[i1].state = 0;   // 右へ
						}
						else if (MP.map[k1+1][k2-1] > 1)
							gp.enemy[i1].state = -1;   // 上へ
					}
				}
			}
							// 敵２
			else if (gp.enemy[i1].type == 1) {
									// 右へ移動
				if (gp.enemy[i1].state == 0) {
					gp.enemy[i1].x += gp.enemy[i1].v;
					var k2 = Math.floor((gp.enemy[i1].x + MP.block_width) / MP.block_width);
					if (k2 >= MP.map_col)
						sw = 1;
					else {
						var k1 = Math.floor(gp.enemy[i1].y / MP.block_height);
						if (MP.map[k1][k2] > 1) {
							gp.enemy[i1].x = (k2 - 1) * MP.block_width;
							var r = Math.random();
							if (k1 == MP.map_row-1 && MP.map[k1-1][k2-1] == 1 
                                                           || k1 > 0 && k1 < MP.map_row-1 && (MP.map[k1+1][k2-1] > 1 
                                                           || r > 0.5 && MP.map[k1+1][k2-1] == 1 && MP.map[k1-1][k2-1] == 1))
								gp.enemy[i1].state = -1;   // 上へ
							else if (k1 == 0 && MP.map[k1+1][k2-1] == 1 
                                                           || k1 > 0 && k1 < MP.map_row-1 && (MP.map[k1-1][k2-1] > 1 
                                                           || r <= 0.5 && MP.map[k1+1][k2-1] == 1 && MP.map[k1-1][k2-1] == 1))
								gp.enemy[i1].state = 1;   // 下へ
						}
					}
				}
									// 上へ移動
				else if (gp.enemy[i1].state < 0) {
					gp.enemy[i1].y -= gp.enemy[i1].v;
					var k1 = Math.floor((gp.enemy[i1].y + MP.block_height) / MP.block_height);
					var k2 = Math.floor(gp.enemy[i1].x / MP.block_width) + 1;
					if (MP.map[k1][k2] == 1) {
						gp.enemy[i1].y = k1 * MP.block_height;
						gp.enemy[i1].state = 0;   // 右へ
					}
					else if (k1 == 0 || MP.map[k1-1][k2-1] > 1)
						gp.enemy[i1].state = 1;   // 下へ
				}
									// 下へ移動
				else {
					gp.enemy[i1].y += gp.enemy[i1].v;
					var k1 = Math.floor(gp.enemy[i1].y / MP.block_height);
					var k2 = Math.floor(gp.enemy[i1].x / MP.block_width) + 1;
					if (k1 >= MP.map_row-1) {
						gp.enemy[i1].y = k1 * MP.block_height;
						if (MP.map[k1][k2] == 1)
							gp.enemy[i1].state = 0;   // 右へ
						else
							gp.enemy[i1].state = -1;   // 上へ
					}
					else {
						if (MP.map[k1][k2] == 1) {
							gp.enemy[i1].y = k1 * MP.block_height;
							gp.enemy[i1].state = 0;   // 右へ
						}
						else if (MP.map[k1+1][k2-1] > 1)
							gp.enemy[i1].state = -1;   // 上へ
					}
				}
			}
							// ゲームオーバーか否か
			if (sw == 0)
				mp.ctx.drawImage(gp.enemy[i1].image, gp.enemy[i1].x, gp.enemy[i1].y, MP.block_width, MP.block_height);
			else {
				clearInterval(gp.timerID);   // タイマーの停止
				gop_start();   // ゲームオーバー
			}
		}
	}
					// 次の敵
	if (gp.count == gp.next_time) {
		gp.n_e_now--;
		gp.count = 0;
		gp.e_state[gp.next] = 1;
		if (gp.n_e_now > 0) {
			gp.next_time = Math.floor(5 * 30 - 30 * Math.random());
			gp.next = -1;
			while (gp.next < 0) {
				gp.next = Math.floor(gp.e_state.length * Math.random());
				if (gp.next >= gp.e_state.length)
					gp.next = gp.e_state.length - 1;
				if (gp.e_state[gp.next] != 0)
					gp.next = -1;
			}
		}
		else
			gp.next_time = -1;
	}
}				
                                //
				// Friend オブジェクト（プロパティ）
				//
function Friend(sw)
{
	this.image = new Image();
	if (sw == 0)
		this.image.src = "image/friend1.png";
//	else
//		this.image.src = "image/friend2.jpg";
	
	this.state = 0;   // 0:左へ移動，1:下へ移動，-1:上へ移動
	
	this.x = 0;
	this.y = 0;
	this.v = 0;   // 移動速度





	
	return this;
}
			//
			// Enemy オブジェクト（プロパティ）
			//
function Enemy(sw)
{
	this.image = new Image();
	if (sw == 0)
		this.image.src = "image/enemy1-5.jpg";
	else
		this.image.src = "image/enemy2.png";

	this.type = sw;   // 敵のタイプ
	this.state = 0;   // 0:右へ移動，1:下へ移動，-1:上へ移動
        this.hp = 3;
	this.x = 0;
	this.y = 10; // Math.floor(MP.map_row * Math.random ());
	if (this.y >= MP.map_row)
		this.y = MP.map_row - 1;
	this.y *= MP.block_height;
	this.v = 2;   // 移動速度
	return this;
}
function Beam(sw)
{
        this.image = new Image();
        if (sw == 0)
                this.image.src = "image/beam.png";
     
        this.type = sw;   // 敵のタイプ
        this.state = 0;   // 0:右へ移動，1:下へ移動，-1:上へ移動
        this.x = 0;
	this.y = 0;
	this.v = 5;
        return this;
}
        
			//
			// GamePanel オブジェクト（メソッド onMouseDown）
			//
GamePanel.prototype.onMouseDown = function(event)
{
	var x_base  = mp.canvas.offsetLeft;   // キャンバスの左上のｘ座標
	var y_base  = mp.canvas.offsetTop;   // キャンバスの左上のｙ座標
	var k1 = Math.floor((event.pageY - y_base) / MP.block_height);
	var k2 = Math.floor((event.pageX - x_base) / MP.block_width);
	if (k1 >= 0 && k1 < MP.map_row && k2 >= 0 && k2 < MP.map_col && MP.map[k1][k2] == 6) {
		gp.mark_x = k2 * MP.block_width;
		gp.mark_y = k1 * MP.block_height;
		gp.mouse = true;
	}
}
			//
			// GamePanel オブジェクト（メソッド onKeyDown）
			//
GamePanel.prototype.onKeyDown = function(event)
{
	if(gp.mouse && event.keyCode >= 49 && event.keyCode <= 51) {
		if (event.keyCode == 49) {   // キー 1
			if (gp.n_friend[0] >0) {
				gp.n_friend[0]--;
				gp.f_state[0][gp.n_friend[0]] = 1;
				gp.friend[0][gp.n_friend[0]].x = gp.mark_x;
				gp.friend[0][gp.n_friend[0]].y = gp.mark_y;
			}
		}
		else if (event.keyCode == 50) {   // キー 2
			if (gp.n_friend[1] >0) {
				gp.n_friend[1]--;
				gp.f_state[1][gp.n_friend[1]] = 1;
				gp.friend[1][gp.n_friend[1]].x = gp.mark_x;
				gp.friend[1][gp.n_friend[1]].y = gp.mark_y;
			}
		}
		gp.mark_x = 0;
		gp.mark_y = 0;
		gp.mouse = false;
	}
}